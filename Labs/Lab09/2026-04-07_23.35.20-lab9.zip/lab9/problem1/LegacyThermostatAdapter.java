/**
 * Adapter that makes LegacyThermostat compatible with SmartDevice interface.
 * This is the Adapter Pattern - adapting an incompatible interface.
 */
public class LegacyThermostatAdapter implements SmartDevice {
    private LegacyThermostat legacyThermostat;

    public LegacyThermostatAdapter(LegacyThermostat legacyThermostat) {
        this.legacyThermostat = legacyThermostat;
    }

    @Override
    public void turnOn() {
        // Adapt turnOn() to activate()
        legacyThermostat.activate();
    }

    @Override
    public void turnOff() {
        // Adapt turnOff() to deactivate()
        legacyThermostat.deactivate();
    }

    @Override
    public String getStatus() {
        // Adapt getStatus() to use legacy methods
        String status = legacyThermostat.isActive() ? "ACTIVE" : "INACTIVE";
        return "Thermostat: " + status + " (Current: " + legacyThermostat.getCurrentTemp() 
               + "°F, Target: " + legacyThermostat.getTargetTemp() + "°F)";
    }

    // Additional method to access legacy functionality
    public void setTargetTemperature(int temp) {
        legacyThermostat.setTargetTemp(temp);
    }
}
