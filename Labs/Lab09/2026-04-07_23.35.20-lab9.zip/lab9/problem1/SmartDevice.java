/**
 * Interface for all smart devices in the system.
 */
public interface SmartDevice {
    void turnOn();
    void turnOff();
    String getStatus();
}
