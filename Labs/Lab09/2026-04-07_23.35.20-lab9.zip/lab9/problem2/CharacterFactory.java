/**
 * Factory for creating pre-configured character templates.
 * This is the Factory Method Pattern for character archetypes.
 */
public class CharacterFactory {

    /**
     * Create a character based on role archetype.
     * @param role The role type: "tank", "dps", "support", "assassin"
     * @param name The character name
     * @return A pre-configured GameCharacter
     */
    public static GameCharacter createCharacter(String role, String name) {
        switch (role.toLowerCase()) {
            case "tank":
                return createTank(name);
            case "dps":
                return createDPS(name);
            case "support":
                return createSupport(name);
            case "assassin":
                return createAssassin(name);
            default:
                throw new IllegalArgumentException("Unknown role: " + role);
        }
    }

    /**
     * Tank template - high health and defense Warrior.
     */
    private static GameCharacter createTank(String name) {
        return new CharacterBuilder()
            .setCharacterType("warrior")
            .setName(name)
            .setHealth(200)
            .setAttack(12)
            .setDefense(30)
            .setWeaponType("Shield & Mace")
            .build();
    }

    /**
     * DPS template - high attack Mage.
     */
    private static GameCharacter createDPS(String name) {
        return new CharacterBuilder()
            .setCharacterType("mage")
            .setName(name)
            .setHealth(70)
            .setAttack(35)
            .setDefense(5)
            .setElementType("Lightning")
            .setMana(150)
            .build();
    }

    /**
     * Support template - balanced Mage with healing focus.
     */
    private static GameCharacter createSupport(String name) {
        return new CharacterBuilder()
            .setCharacterType("mage")
            .setName(name)
            .setHealth(90)
            .setAttack(15)
            .setDefense(15)
            .setElementType("Holy")
            .setMana(200)
            .build();
    }

    /**
     * Assassin template - high precision Archer.
     */
    private static GameCharacter createAssassin(String name) {
        return new CharacterBuilder()
            .setCharacterType("archer")
            .setName(name)
            .setHealth(85)
            .setAttack(28)
            .setDefense(10)
            .setPrecision(98)
            .setBowType("Crossbow")
            .build();
    }

    /**
     * Create a basic character of specified class.
     */
    public static GameCharacter createBasicCharacter(String characterClass, String name) {
        return new CharacterBuilder()
            .setCharacterType(characterClass)
            .setName(name)
            .build();
    }
}
